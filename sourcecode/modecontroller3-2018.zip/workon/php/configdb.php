<?php 
$servername = "localhost";
$username = "root";
$password = "jungle2017";
$dbname = "db_machine_web_controller";
 ?>