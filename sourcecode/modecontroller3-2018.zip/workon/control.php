<?php  
if (isset($_GET['matrix_data'])) {
    echo "AAAAAA.BBBBBB";
}
?>