<?php 
$servername = "localhost";
$username = "root";
$password = "jungle2017";
$database = "db_machine_web_controller";

?>